const jwt = require("jsonwebtoken");
require("dotenv").config();

module.exports = function(req, res, next) {
  
  const token = req.header("jwt_token"); 

  if (!token) {
    // if no jwt token, function stops. if true, return true, later, in router.post("/verify"
    return res.status(403).json({ msg: "Not Authorized" });
  }

  try { // Verify token, it is going to give the user id (user:{id: user.id})
    const verify = jwt.verify(token, 'jwt123');
    req.user = verify.user; // req.user gives u the unique current logged in user id, parsed on
    next();
  } catch (err) {
    res.status(401).json({ msg: "Token is not valid" });
  }
};
