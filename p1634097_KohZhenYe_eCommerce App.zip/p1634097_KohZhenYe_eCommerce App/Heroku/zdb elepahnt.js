const Pool = require("pg").Pool;

const pool = new Pool({
  connectionString:
    "postgres://annmitae:4PyCkDOuI85oTngw5WcRhR2TqqKxv3sE@rosie.db.elephantsql.com/annmitae",
});

pool.connect();

pool.query(
  `
  DROP TABLE IF EXISTS ITEMS;
CREATE TABLE items(
  item_id uuid DEFAULT uuid_generate_v4(),
  user_id UUID,
  description VARCHAR(255) NOT NULL,
  item_name VARCHAR (255) NOT NULL,
  quantity VARCHAR (255) NULL,
  PRIMARY KEY (item_id),
  FOREIGN KEY (user_id) REFERENCES users(user_id)
);


`,
  (err, res) => {
    console.log(err, res);
    pool.end();
  }
);

//postgres://annmitae:4PyCkDOuI85oTngw5WcRhR2TqqKxv3sE@rosie.db.elephantsql.com/annmitae

// INSERT INTO storage (storage_name) VALUES ('hello world') RETURNING *

/*
UPDATE USERS set user_type = 'admin' WHERE user_email = 'admin@a.com' 
DELETE FROM users WHERE user_email = 'admin@a.com' RETURNING *
INSERT INTO users (user_name, user_email, user_password, user_type) VALUES ('admin', 'admin@a.com', '123', 'admin') RETURNING *
*/ 

// select users.user_password from users where users.user_email = 'admin@a.com'