-- CREATE DATABASE database;
-- ALTER TABLE users ADD COLUMN user_type VARCHAR (255) NULL

CREATE TABLE users(
  user_id uuid DEFAULT uuid_generate_v4(),
  user_name VARCHAR(255) NOT NULL,
  user_email VARCHAR(255) NOT NULL UNIQUE,
  user_password VARCHAR(255) NOT NULL,
  user_type VARCHAR (255) NULL,
  PRIMARY KEY(user_id)
);

DROP TABLE IF EXISTS storage

CREATE TABLE storage (
  storage_id uuid DEFAULT uuid_generate_v4(),
  storage_name VARCHAR (255) NOT NULL,
  storage_description VARCHAR (255) NOT NULL,
  PRIMARY KEY(storage_id)
)


DROP TABLE IF EXISTS ITEMS;
CREATE TABLE items(
  item_id uuid DEFAULT uuid_generate_v4(),
  user_id UUID,
  description VARCHAR(255) NOT NULL,
  item_name VARCHAR (255) NOT NULL,
  PRIMARY KEY (item_id),
  FOREIGN KEY (user_id) REFERENCES users(user_id)


INSERT INTO storage (storage_name, storage_description) VALUES ('name 1','description 1')
INSERT INTO storage (storage_name, storage_description) VALUES ('name 2','description 2')
INSERT INTO storage (storage_name, storage_description) VALUES ('name 3','description 3')
