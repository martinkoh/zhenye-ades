import React, { Fragment, useState, useEffect } from "react";
import "./App.css";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";

//components
import Home from "./components/Home";
import Login from "./components/Login";
import Register from "./components/Register";
import Dashboard from "./components/Dashboard";
import Admin from "./components/Admin";
import Profile from "./components/Profile";

toast.configure();

function App() {




  // Admin
  const [isAdmin, setIsAdmin] = useState(false); //by default, isAdmin is false.
  const checkAdmin = async () => {
    try {

      const admin = await fetch("/authentication/admin", {
        method: "GET",
        headers: { jwt_token: localStorage.token }
      });
      const adminRes = await admin.json()

      //console.log(adminRes.user_type, '5')

      adminRes.user_type ===  'admin' ? setIsAdmin(true) : setIsAdmin(false);
    } catch (err) {
      console.error(err.message);
    }
  };
  
  useEffect(() => {
    checkAdmin();
  }, []);

  const setAdmin = boolean => {
    setIsAdmin(boolean);
  };





  // jwtAuth
  const [isAuthenticated, setIsAuthenticated] = useState(false); //by default, authentication is false.
  const checkAuthenticated = async () => {
    try {
      const res = await fetch("/authentication/verify", {
        method: "POST",
        headers: { jwt_token: localStorage.token }
      });

      const parseRes = await res.json();

      parseRes === true ? setIsAuthenticated(true) : setIsAuthenticated(false);

    } catch (err) {
      console.error(err.message);
    }
  };

  useEffect(() => {
    checkAuthenticated();
  }, []);

  const setAuth = boolean => { // function name setAuth, function param boolean; takes in true or false from the setAuth props in login component
    setIsAuthenticated(boolean); // setIsAuthenticated becomes true or false... if True, then isAuthenticated(the react state) becomes True. If isAuthenticated is true, redirect to the route u want. (the useEffect() constantly checkAuthenticated()?)
  };





  return (
    <Fragment>
      <Router>
        <div className="container">
          <Switch>
            <Route
              exact
              path="/" // DETERMINES home url "/" from Home.js component
              render={(props) =>
                !isAuthenticated ?  ( // if not authenticated
                  <Home {...props} /> // go to home page
                ) : (
                  <Redirect to="/dashboard" /> // else go to dashboard
                )
              }
            />
            <Route
              exact
              path="/login" // DETERMINES "login/" url from Login.js component
              render={(props) =>
                !isAuthenticated ? (<Login {...props} setAuthh={setAuth} setAdminn={setAdmin}/>)
                  : isAdmin ? (<Redirect to="/admin" />)
                  :(<Redirect to="/dashboard" />)
              }
            />
            <Route
              exact
              path="/register"
              render={(props) =>
                !isAuthenticated ? (
                  <Register {...props} setAuth={setAuth} setAdminn={setAdmin} />
                )
                  : isAdmin ? (<Redirect to="/admin" />)
                  : (<Redirect to="/dashboard" />
                )
              }
            />
            <Route
              exact
              path="/admin"
              render={(props) =>
                isAuthenticated ? (
                  <Admin {...props} setAuth={setAuth} setAdmin={setAdmin} />
                ) : (
                  <Redirect to="/" /> // in dashboard.js, once logged out, the setAuth becomes false. then redirect to Home
                )
              }
            />
            <Route
              exact
              path="/dashboard"
              render={(props) =>
                isAdmin ? (<Redirect to="/admin" />)
                :isAuthenticated ? (
                  <Dashboard {...props} setAuth={setAuth} />
                ) : (
                  <Redirect to="/" /> // in dashboard.js, once logged out, the setAuth becomes false. then redirect to Home
                )
              }
            />
            <Route
              exact
              path="/profile"
              render={(props) =>
                isAuthenticated ? (
                  <Profile {...props} setAuth={setAuth} />
                ) : (
                  <Redirect to="/" />
                )
              }
            />
          </Switch>
        </div>
      </Router>
    </Fragment>
  );
}

export default App;
