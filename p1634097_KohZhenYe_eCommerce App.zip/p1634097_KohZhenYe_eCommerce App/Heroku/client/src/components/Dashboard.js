import React, { useEffect, useState, Fragment } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";


const Dashboard = ({ setAuth }) => {
  

  //GET PROFILE NAME OF CUSTOMER
  const [name, setName] = useState("");
  const getProfile = async () => {
    try {
      const res = await fetch("/", {
        method: "GET",
        headers: { jwt_token: localStorage.token }
      });

      const parseData = await res.json();
      setName(parseData.user_name);
    } catch (err) {
      // console.error(err.message);
    }
  };




  // GET ALL ITEMS FOR CUSTOMER TO SEE IN DASHBOARD
  const [items, setItems] = useState([]); //empty array
  const getItems = async () => {
    try {
      const res = await fetch("/allItems");

      const parseData = await res.json();
      setItems(parseData)
    } catch (err) {
      console.error(err.message);
    }
  };




   useEffect(() => {
     getProfile();
     getItems();
  });





const logout = async (e) => {
  e.preventDefault();
  try {
    localStorage.removeItem("token");
    setAuth(false);
    toast.success("Logout successfully"); // notification
  } catch (err) {
    console.error(err.message);
  }
};
  
  

  return (
    <div>
      <div className="mt-5"></div>
      <h2 id='currentProfileName'>Welcome {name}</h2>
      <Link to="/profile" className="btn btn-dark">
        My Profile
      </Link>
      <button onClick={(e) => logout(e)} className="btn btn-primary">
        Logout
      </button>
    
      


      <h1 className="mt-5">Products</h1>
      <div className="row">
        <div className="col-sm-12">
        {items.length !== 0 &&
            items[0].item_id !== null &&
            items.map(item => (
              <div key={item.item_id}>
            
                
                <div className="card">
                  <div className="card-body">
                    <h5 className="card-title">{item.item_name}</h5>
                    <p className="card-text">{item.description}</p>
                    <a href="#" className="btn btn-primary">View More</a>
                  </div>
                </div>
              </div>      
            ))}
        </div>
      </div>


      {/*<Fragment>
        <div className="mt-5">Item on sale</div>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Description</th>
          </tr>
        </thead>
        <tbody>
         {items.length !== 0 &&
            items[0].item_id !== null &&
            items.map(item => (
              <tr key={item.item_id}>
                <td>{item.item_name}</td>
                <td>{item.description}</td>
            
                <td>

                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </Fragment> */}
      


    

    </div>
  );
};



export default Dashboard;
