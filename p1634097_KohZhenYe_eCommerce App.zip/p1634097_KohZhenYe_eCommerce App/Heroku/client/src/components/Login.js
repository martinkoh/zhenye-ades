import React, { Fragment, useState } from "react";
import { Link, Redirect } from "react-router-dom";

import { toast } from "react-toastify";

const Login = ({ setAuthh , setAdminn}) => { 
  const [inputs, setInputs] = useState({ // initially the inputs is " ". once setInputs function triggered, from the client, the values replaces the " "
    email: "",
    password: ""
  });


  const { email, password } = inputs; //inputs from the usestate 

  const onChange = e =>
    setInputs({ ...inputs, [e.target.name]: e.target.value });

  const onSubmitForm = async e => {
    e.preventDefault();
    try {
      const body = { email, password };
      const response = await fetch(
        "/authentication/login", // linked to router.post/login in jwtAuth.js; authentication/ linked to app.use("/authentication", in server.js
        {
          method: "POST",
          headers: {
            "Content-type": "application/json",
          },
          body: JSON.stringify(body),
        }
      );
      const parseRes = await response.json();

      if (parseRes.jwtToken) {
        localStorage.setItem("token", parseRes.jwtToken);

        //admin
        if (parseRes.isAdmin == 'admin') {
          setAdminn(true) // setAdmin function MUST COME FIRST!!!!!!
        }
        else {
          setAdminn(false)
        }
        
        //jwtAuth
        setAuthh(true);
        toast.success("Logged in Successfully");
      } else {
        setAuthh(false);
        toast.error(parseRes);
      }
    } catch (err) {
      console.error(err.message);
    }
  };

  
  return (
    <Fragment>
      <h1 className="mt-5 text-center">Login</h1>
      <form onSubmit={onSubmitForm}> {/* linked to const onSubmitForm = async e => { */}
        <input
          type="text"
          name="email"
          value={email}
          onChange={e => onChange(e)}
          className="form-control my-3"
        />
        <input
          type="password"
          name="password"
          value={password}
          onChange={e => onChange(e)}
          className="form-control my-3"
        />
        <button className="btn btn-dark">Submit</button>
      </form>
      <Link to="/register">No Account? Register now!</Link>
    </Fragment>
  );
};

export default Login;
