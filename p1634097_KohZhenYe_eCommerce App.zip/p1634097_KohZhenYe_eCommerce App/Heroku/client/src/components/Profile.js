import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";

const Profile = ({ setAuth }) => {

  //set current profileInfo , of names and email only.
  const [currentName, setCurrentName] = useState("");
  const [currentEmail, setCurrentEmail] = useState("");
  const getProfileInfo = async () => {
    try {
      const res = await fetch("/profileInfo", {
        method: "GET",
        headers: { jwt_token: localStorage.token }
      });
      const parseData = await res.json() // contains the unique user id 
      setCurrentName(parseData.user_name);
      setCurrentEmail(parseData.user_email);
      
    } catch (err) {
      console.error(err.message);
    }
  };
  useEffect(() => {
    getProfileInfo();
  }, []);


  // EDIT PROFILE
// get the current profileID as currentID
  const [currentID, setName] = useState("");
  const getProfileID = async () => {
    try {
      const res = await fetch("/getProfileID", {
        method: "GET",
        headers: { jwt_token: localStorage.token }
      });
      const parseData = await res.json() // contains the unique user id 
      setName(parseData.user_id);
    } catch (err) {
      console.error(err.message);
    }
  };
  useEffect(() => {
    getProfileID();
  }, []);

  //
  const [inputs, setInputs] = useState({
    editEmail: "", 
    editPassword: "",
    editName: ""
  });
  const { editEmail, editPassword, editName } = inputs;

  const onChange = e =>
    setInputs({ ...inputs, [e.target.name]: e.target.value }); // e.target the <input name> = <input value>

  const onSubmitForm = async e => { // submit to rest API to get jwt token
    e.preventDefault(); // prevent refresh
    try {
      const body = { currentID, editEmail, editPassword, editName };
      const response = await fetch(
        "/authentication/profile",
        {
          method: "PUT",
          headers: {
            "Content-type": "application/json",
          },
          body: JSON.stringify(body),
        }
      );
      const parseRes = await response.json(); //returns jwt token, from backend, jwtauth.js: return res.json({ jwtToken });

      if (parseRes.jwtToken) {
        localStorage.setItem("token", parseRes.jwtToken);
        setAuth(true);
        toast.success("Updated Profile Successfully");
      } else {
        setAuth(false);
        toast.error(parseRes);
      }
    } catch (err) {
      console.error(err.message);
    }
  };
  //

  const deleteProfile = async (e) => {
    
    e.preventDefault();
    try {

      const body = { currentID };
      await fetch(
        "/authentication/profile",
        {
          method: "DELETE",
          headers: {
            "Content-type": "application/json",
          },
          body: JSON.stringify(body),
        }
      );

      localStorage.removeItem("token");
      setAuth(false);
      toast.info("Account Deleted Successfully"); // notification
    } catch (err) {
      console.error(err.message);
    }
  };
  
  //
  const logout = async (e) => {
    e.preventDefault();
    try {
      localStorage.removeItem("token");
      setAuth(false);
      toast.success("Logout successfully"); // notification
    } catch (err) {
      console.error(err.message);
    }
  };
  //

  return (
    <div>
      
      <h1 className="mt-5">Profile</h1>
  
      <button onClick={(e) => logout(e)} className="btn btn-primary">
        Logout
      </button>
    
      <div className="jumbotron mt-5">
        <h3>Edit Profile</h3> {/* Edit Profile section */}
        <form onSubmit={onSubmitForm}>
          {/* <input
          type="text"
          name="editEmail"
          value={editEmail} // to the inputs
          placeholder={currentEmail}
          onChange={(e) => onChange(e)} 
          className="form-control my-3" //margin "y" of 3
        /> */}
          <p>Current Email: {currentEmail}</p>
          <p>change password</p>
        <input
          type="password"
          name="editPassword"
          value={editPassword} // to the inputs
          placeholder="password"
          onChange={(e) => onChange(e)}
          className="form-control my-3"
          />
        <p>Edit Name</p>
        <input
          type="text"
          name="editName"
          value={editName} // to the inputs
          placeholder={currentName}
          onChange={(e) => onChange(e)}
          className="form-control my-3"
        />
          <button className="btn btn-dark ">Update</button>
          <div className="mt-5"></div>
        </form>
        <button onClick={(e) => deleteProfile(e)} className="btn btn-danger">
        Delete Profile
      </button>
      </div> {/* END Edit Profile section */}  
      
      
    </div>
  );
};

export default Profile;
