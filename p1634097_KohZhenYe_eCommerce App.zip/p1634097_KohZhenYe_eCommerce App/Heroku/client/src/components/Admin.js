import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";

import SearchItem from "./itemlist/SearchItem";
import AddItem from "./itemlist/AddItem";
import ListItems from "./itemlist/ListItems";

const Admin = ({ setAuth }) => {

  const [name, setName] = useState("");

  //
  const [allitems, setAllitems] = useState([]);
  const [itemsChange, setitemsChange] = useState(false);

  const getProfile = async () => {
    try {
      const res = await fetch("/items", {
        method: "GET",
        headers: { jwt_token: localStorage.token }
      });

      const parseData = await res.json();

      setAllitems(parseData);

      setName(parseData[0].user_name);
      
    } catch (err) {
      console.error(err.message);
    }
  };

  useEffect(() => {
    getProfile();
    setitemsChange(false);
  }, [itemsChange]);



const logout = async (e) => {
  e.preventDefault();
  try {
    localStorage.removeItem("token");
    setAuth(false);
    toast.success("Logout successfully"); // notification
  } catch (err) {
    console.error(err.message);
  }
};

  return (
    <div>
      <div className="mt-5"></div>
      <h2 id="currentProfileName">Welcome {name}</h2>
      <Link to="/profile" className="btn btn-dark">
        My Profile
      </Link>
      <button onClick={(e) => logout(e)} className="btn btn-primary">
        Logout
      </button>


      <h1 className="mt-5">Admin Panel</h1>
        <div className="row mt-3">
          <div className="col-sm-12">
            <div className="card">
              <div className="card-body">
              <AddItem setitemsChange={setitemsChange} />
              <ListItems allitems={allitems} setitemsChange={setitemsChange} />
              </div>
            </div>
        </div>

        <div className="mt-5">.</div>
        
          <div className="col-sm-12">
            <div className="card">
            <div className="card-body">
              
            <SearchItem></SearchItem>

              
              </div>
            </div>
          </div>
        </div>
    </div>
  );
};



export default Admin;
