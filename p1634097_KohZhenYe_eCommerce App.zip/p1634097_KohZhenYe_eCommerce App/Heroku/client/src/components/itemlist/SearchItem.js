import React, { Fragment, useState } from "react";
import { toast } from "react-toastify";

function Adminitem() {

  const [item_id, set_item_id] = useState(""); //set a default uuid, must be valid.
  //when form submit,  set_item_id from form will overwrite item_id, to be sent to fetch api
  
  const [item, setitem] = useState([]); // the response, show the item output, used in item.map below

  const onSubmitForm = async e => {
    e.preventDefault(); // dotn refresh
    try {
      const response = await fetch(`/itemByID/?item_id=${item_id}`);

      const parseResponse = await response.json();

      setitem(parseResponse); //sets "item" values from response, to be used in item.map
      console.log(parseResponse);
      if (parseResponse.length == 0) {
        toast.error('No Item Found');
      }
      
    } catch (err) {
      console.error(err.message);
    }
  };
  return (
    <Fragment>
      <div className="container text-center">
        <h2 className="">Search Item By Name</h2>
        <form className="d-flex" onSubmit={onSubmitForm}>
          <input
            type="text"
            name="name"
            placeholder="Enter item name"
            className="form-control"
            value={item_id}
            onChange={e => set_item_id(e.target.value)}
          />
          <button className="btn btn-success">Submit</button>
        </form>
        <table className="table my-5">
          <thead>
            <tr>
              <th>Item Name</th>
              <th>Item Description</th>
              <th>Stock Quantity</th>
            </tr>
          </thead>
          <tbody>
            {item.map( i => (
              <tr key={i.item_id}>
                <td id='python1'>{i.item_name}</td>
                <td>{i.description}</td>
                <td>{i.quantity}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {item.length === 0 && <p>No Results Found</p>}
        
      </div>
    </Fragment>
  );
}

export default Adminitem;
