import React, { Fragment, useState } from "react";

const EditItem = ({ item, setitemsChange }) => {
  //editText function

  const editText = async id => {
    try {
      const body = { item_name, description, stockQuantity };

      const myHeaders = new Headers();

      myHeaders.append("Content-Type", "application/json");
      myHeaders.append("jwt_token", localStorage.token);

      await fetch(`/items/${id}`, {
        method: "PUT",
        headers: myHeaders,
        body: JSON.stringify(body)
      });

      setitemsChange(true);

      // window.location = "/";
    } catch (err) {
      console.error(err.message);
    }
  };

  const [item_name, setItemName] = useState(item.item_name);
  const [description, setDescription] = useState(item.description);
  const [stockQuantity , setStockQuantity] = useState(item.quantity);
  

  return (
    <Fragment>

      <button
        type="button"
        className="btn btn-warning"
        data-toggle="modal"
        data-target={`#id${item.item_id}`}
      >
        Edit
      </button>

      
      <div
        className="modal"
        id={`id${item.item_id}`}
        
      > {/* added 2 functions onClick={() => { setDescription(item.description); setItemName(item.item_name)} } */}

        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">Edit Item</h4>
              {/* <button
                type="button"
                className="close"
                data-dismiss="modal"
                onClick={() => setDescription(item.description)}
              >
                &times;
              </button>*/}
              
            </div>

            <div className="modal-body">

              Edit Item Name
              <input
                type="text"
                className="form-control"
                value={item_name}
                onChange={e => setItemName(e.target.value)}
              />

              <div className="mt-3"></div>

              Edit Item Description
              <input
                type="text"
                className="form-control"
                value={description}
                onChange={e => setDescription(e.target.value)}
              />

              Edit Stock
              <input
                type="text"
                className="form-control"
                value={stockQuantity}
                onChange={e => setStockQuantity(e.target.value)}
              />

            </div>

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-warning"
                data-dismiss="modal"
                onClick={() => editText(item.item_id)}
              >
                Edit
              </button>
              <button
                type="button"
                className="btn btn-danger"
                data-dismiss="modal" 
              >
                {/*onClick={() => setDescription(item.description)}*/}
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default EditItem;
