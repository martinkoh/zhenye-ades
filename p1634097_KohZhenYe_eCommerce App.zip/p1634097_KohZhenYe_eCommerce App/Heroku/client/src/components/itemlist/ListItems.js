import React, { Fragment, useState, useEffect } from "react";
import EditItem from "./EditItem";

const ListItems = ({ allitems, setitemsChange }) => {

  const [items, setitems] = useState([]); //empty array

  //delete item function

  async function deleteitem(id) {
    try {
      await fetch(`/items/${id}`, {
        method: "DELETE",
        headers: { jwt_token: localStorage.token }
      });

      setitems(items.filter(item => item.item_id !== id));
    } catch (err) {
      console.error(err.message);
    }
  }

  // async function getitems() {
  //   const res = await fetch("/items");

  //   const itemArray = await res.json();

  //   setitems(itemArray);
  // }

  useEffect(() => {
    setitems(allitems);
  }, [allitems]);


  return (
    <Fragment>
      <h4 className="mt-5">
          My Added Items
         </h4>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Stock Quantity</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {/*<tr>
            <td>John</td>
            <td>Doe</td>
            <td>john@example.com</td>
          </tr> */}

          {items.length !== 0 &&
            items[0].item_id !== null &&
            items.map(item => (
              <tr key={item.item_id}>
                <td>{item.item_name}</td>
                <td>{item.description}</td>
                <td>{item.quantity}</td>
                <td>
                  <EditItem item={item} setitemsChange={setitemsChange} />
                </td>
                <td>
                  <button
                    className="btn btn-danger"
                    onClick={() => deleteitem(item.item_id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </Fragment>
  );
};

export default ListItems;
