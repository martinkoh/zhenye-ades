import React, { Fragment, useState } from "react";


const AddItem = ({ setitemsChange }) => {
  const [description, setDescription] = useState("");
  const [item_name, setItemName] = useState("");
  const [stockQuantity , setStockQuantity] = useState("");

  const onSubmitForm = async e => {
    e.preventDefault();
    try {
      const myHeaders = new Headers();

      myHeaders.append("Content-Type", "application/json");
      myHeaders.append("jwt_token", localStorage.token);

      const body = { description, item_name, stockQuantity };
      const response = await fetch("/items", {
        method: "POST",
        headers: myHeaders,
        body: JSON.stringify(body)
      });

      const parseResponse = await response.json();

      console.log(parseResponse);

      setitemsChange(true);
      setDescription("");
      setItemName("");
      setStockQuantity("")
      // window.location = "/";
    } catch (err) {
      console.error(err.message);
    }
  };


/*
  const [imageSelected, setImageSelected] = useState("")
  const uploadImage = () => {
     const formData = new FormData()
    formData.append("file", imageSelected)
    formData.append("upload_preset", "ca2_ades")

    Axios.post(
      "https://api.cloudinary.com/v1_1/dzagqt21o/image/upload",
      formData
    ).then((response) =>
    {
      console.log(response);
      }
    )
   
  }
 */
  
  return (

    <Fragment>

      <h1 className="text-center my-3">Add Item</h1>

      <form className="d-flex" onSubmit={onSubmitForm}>
        <input
          type="text"
          placeholder="add item name"
          className="form-control"
          value={item_name}
          onChange={e => setItemName(e.target.value)}
        />
        <input
          type="text"
          placeholder="add item description"
          className="form-control"
          value={description}
          onChange={e => setDescription(e.target.value)}
        />
        <input
          type="text"
          placeholder="stock level"
          className="form-control"
          value={stockQuantity}
          onChange={e => setStockQuantity(e.target.value)}
        />
        <button className="btn btn-success ">Add</button>
      </form>
    </Fragment>

  );
};

export default AddItem;
