const Pool = require("pg").Pool;

const pool = new Pool({
  connectionString:
    "postgres://annmitae:4PyCkDOuI85oTngw5WcRhR2TqqKxv3sE@rosie.db.elephantsql.com/annmitae"
});

// client
// pool.connect();

module.exports = pool;

