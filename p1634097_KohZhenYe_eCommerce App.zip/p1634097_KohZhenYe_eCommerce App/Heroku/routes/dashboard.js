const router = require("express").Router();
const authorize = require("../middleware/authorize");
const pool = require("../db");

// 2 exact same routes..
router.get("/", authorize, async (req, res) => {
  try {
    const user = await pool.query(
      "SELECT user_name, user_type FROM users WHERE user_id = $1", 
      [req.user.id]
    );
    res.json(user.rows[0]); // returns user_name and user_type
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});


router.post("/", authorize, async (req, res) => {
  try {
    const user = await pool.query(
      "SELECT user_name, user_type FROM users WHERE user_id = $1", 
      [req.user.id]
    );
    res.json(user.rows[0]); //e.g user.rows[0] here, is { user_name: 'b' }
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});



router.get("/getProfileID", authorize, async (req, res) => {
  try {
    const user = await pool.query(
      "SELECT user_id FROM users WHERE user_id = $1", //get only the user_name from psql
      [req.user.id]
    );
    res.json(user.rows[0]); //e.g user.rows[0] here, is { user_name: 'b' }
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

router.get("/profileInfo", authorize, async (req, res) => {
  try {
    const user = await pool.query(
      "SELECT user_name, user_email FROM users WHERE user_id = $1", //get only the user_name from psql
      [req.user.id]
    );
    res.json(user.rows[0]); //e.g user.rows[0] here, is { user_name: 'b' }
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});



module.exports = router;
