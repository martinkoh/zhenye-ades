const express = require("express");
const router = express.Router();
const pool = require("../db");
const authorize = require("../middleware/authorize");

//get all items for customer
router.get("/allItems", async (req, res) => {
  try {
    const items = await pool.query(
      "SELECT item_id, item_name, description from items"
    );
    res.json(items.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

// GET all items for an admin
router.get("/items", authorize, async (req, res) => {
  try {
    const user = await pool.query(
      "SELECT u.user_name, t.item_id, t.description, t.item_name, t.quantity FROM users AS u LEFT JOIN items AS t ON u.user_id = t.user_id WHERE u.user_id = $1",
      [req.user.id]
    );

    res.json(user.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

// Search: get the specific item by id
router.get("/itemByID", async (req, res) => {
  try {
    const { item_id } = req.query;
    if (item_id == '') { 
      
    }
    else {
      const items = await pool.query(
      `SELECT item_name, description, quantity FROM items WHERE (item_name ilike $1)`,
      [`%${item_id}%`]
    );
    res.json(items.rows);
    }
  } catch (err) {
    console.error(err.message);
  }
});

//add item
router.post("/items", authorize, async (req, res) => {
  try {
    const {item_name, description, stockQuantity} = req.body;
    const newItem = await pool.query(
      "INSERT INTO items (user_id, item_name, description, quantity) VALUES ($1, $2, $3, $4) RETURNING *",
      [req.user.id, item_name, description, stockQuantity]
    );

    console.log(newItem.rows[0])
    res.json(newItem.rows[0]);
  } catch (err) {
    console.error(err.message);
  }
});


router.put("/items/:id", authorize, async (req, res) => {
  try {
    const { id } = req.params;
    const { item_name, description, stockQuantity } = req.body;
    const updateitem = await pool.query(
      "UPDATE items SET item_name = $1, description = $2, quantity = $3 WHERE item_id = $4 AND user_id = $5 RETURNING *",
      [item_name, description, stockQuantity, id, req.user.id]
    );

    if (updateitem.rows.length === 0) {
      return res.json("This item is not yours");
    }

    res.json("item was updated");
  } catch (err) {
    console.error(err.message);
  }
});

router.delete("/items/:id", authorize, async (req, res) => {
  try {
    const { id } = req.params;
    const deleteitem = await pool.query(
      "DELETE FROM items WHERE item_id = $1 AND user_id = $2 RETURNING *",
      [id, req.user.id]
    );

    if (deleteitem.rows.length === 0) {
      return res.json("This item is not yours");
    }

    res.json("item was deleted");
  } catch (err) {
    console.error(err.message);
  }
});

module.exports = router;

/*
router.post("/storage", async (req, res) => {
   const { storage_name } = req.body; 
  try {

   let insertStorage = await pool.query(
      "INSERT INTO storage (storage_name) VALUES ($1) RETURNING *",
       [storage_name] 
    );

    // const jwtToken = jwtGenerator(newUser.rows[0].user_id); // generate jwt token
    //return res.json({ jwtToken });
    const storage_id = await pool.query("SELECT storage_id FROM storage WHERE storage_name = $1", [
      storage_name 
    ]);
      
    return res.status(201).json({ 'key': insertStorage.rows[0].storage_id });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});


router.get("/item/:item_id", async (req, res) => {
  try {
    var item_id = req.params.item_id;
    console.log(item_id)
     const item = await pool.query(
      "SELECT * FROM item WHERE item_id = $1",
      [item_id]
    );
    res.status(200).json(item.rows); 
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});
*/