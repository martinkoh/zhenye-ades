const express = require("express");
const app = express();
const cors = require("cors");
const path = require("path");

const PORT = process.env.PORT || 5000;



//middleware
app.use(cors());
app.use(express.json()); //req.body

app.use(express.static(path.join(__dirname, "client/build")));


//routes

app.use("/authentication", require("./routes/jwtAuth"));
app.use("/", require("./routes/dashboard"));
app.use("/", require("./routes/item"));
app.get("/*", function(req, res) {
        res.sendFile(path.join(__dirname, "client/build"));
      });

app.listen(PORT, () => {
  console.log(`Server is starting on port ${PORT}`);
});