const jwt = require("jsonwebtoken");

function jwtGenerator(user_id) {
  const payload = { // req.user if const payload = {user: user_id  
    user: { 
      id: user_id,
    },
  };
  return jwt.sign(payload, 'jwt123', { expiresIn: "1h" });
}

module.exports = jwtGenerator;
