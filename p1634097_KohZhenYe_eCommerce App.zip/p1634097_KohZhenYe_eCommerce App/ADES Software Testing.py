#pip install selenium/webdriver-manager

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver import ActionChains #solved not clickable
import time
from random import randrange

import winsound

driver = webdriver.Chrome(ChromeDriverManager().install())
actions = ActionChains(driver)

driver.maximize_window()
driver.delete_all_cookies()

from selenium.common.exceptions import NoSuchElementException






def check_exists_by_xpath(xpath):
    try:
        driver.find_element_by_xpath(xpath)
    except NoSuchElementException:
        return False
    return True



adminPassedTests = []
adminFailedTests = []

userPassedTests = []
userFailedTests = []


def adminLogin():
    username = "admin@a.com"
    password = "123"
    url = 'https://ades-ecommerce.herokuapp.com/'
    driver.get(url)

    #login
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div/div/div/div[1]/div/div/a').click() 
    time.sleep(4)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/input[1]').send_keys(username)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/input[2]').send_keys(password)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/button').click()
    time.sleep(4)
    if (driver.current_url) == ('https://ades-ecommerce.herokuapp.com/admin'):
        adminPassedTests.append('Admin Login')
        print('Admin Login Test Passed')
    else:
         adminFailedTests.append('Admin Login')
         

    #Add Item
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div[2]/div[1]/div/div/form/input[1]').send_keys('Test Name')
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div[2]/div[1]/div/div/form/input[2]').send_keys('Test Description')
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div[2]/div[1]/div/div/form/input[3]').send_keys('Test Stock')
    time.sleep(4)
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div[2]/div[1]/div/div/form/button').click()
    time.sleep(5)
    if ('Test Name' in driver.page_source):
        adminPassedTests.append('Add Product')
        print('Add Product Test Passed')
    else:
         adminFailedTests.append('Add Product')


    #edit Item
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div[2]/div[1]/div/div/table/tbody/tr/td[4]/button').click()
    time.sleep(4)
    driver.find_element_by_xpath('/html/body/div[1]/div/div/div[2]/div[1]/div/div/table/tbody/tr[1]/td[4]/div/div/div/div[2]/input[1]').send_keys(' EDITED')
    driver.find_element_by_xpath('/html/body/div[1]/div/div/div[2]/div[1]/div/div/table/tbody/tr[1]/td[4]/div/div/div/div[2]/input[2]').send_keys(' EDITED')
    driver.find_element_by_xpath('/html/body/div[1]/div/div/div[2]/div[1]/div/div/table/tbody/tr[1]/td[4]/div/div/div/div[2]/input[3]').send_keys(' EDITED')
    time.sleep(2)
    driver.find_element_by_xpath('/html/body/div[1]/div/div/div[2]/div[1]/div/div/table/tbody/tr[1]/td[4]/div/div/div/div[3]/button[1]').click()
    time.sleep(4)
    if ('EDITED' in driver.page_source):
        adminPassedTests.append('Edit Product')
        print('Edit Product Test Passed')
    else:
        adminFailedTests.append('Edit Product')



#Search Item
    driver.find_element_by_xpath('/html/body/div[1]/div/div/div[2]/div[3]/div/div/div/form/input').send_keys(' EDITED')
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div[2]/div[3]/div/div/div/form/button').click()
    time.sleep(4)
    try:
        if ('EDITED' in driver.find_element_by_xpath('//*[@id="root"]/div/div/div[2]/div[3]/div/div/div/table/tbody/tr[1]/td[1]').text):
            adminPassedTests.append('Search Product')
            print('Search Product Test Passed')
    except NoSuchElementException:
        adminFailedTests.append('Search Product')
        pass



    #edit profile
    time.sleep(5)
    driver.find_element_by_xpath('//*[@id="root"]/div/div/a').click()
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div/form/input[1]').send_keys(123)
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div/form/input[2]').send_keys('Admin (Updated)')
    time.sleep(4)
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div/form/button').click()
    time.sleep(4)
    driver.execute_script("window.history.go(-1)")
    time.sleep(5)
    if (True):
        adminPassedTests.append('Edit Profile')
        print('Edit Profile Test Passed')
    else:
        adminFailedTests.append('Edit Profile')
    time.sleep(4)


    #admin logout
    driver.find_element_by_xpath('//*[@id="root"]/div/div/button').click()
    if (True):
        adminPassedTests.append('Admin Logout')
        print('Admin Logout Test Passed')
    else:
        adminFailedTests.append('Admin Logout')
    time.sleep(4)

    print('Admin Panel Passed Tests:', adminPassedTests)
    print('Admin Panel Failed tests:', adminFailedTests)





def customerLogin():

    username = "test2323222@test.com"
    password = "123"
    url = 'https://ades-ecommerce.herokuapp.com/'
    driver.get(url)

    #login
    time.sleep(3)
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div/div/div/div[2]/div/div/a').click()
    time.sleep(1)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/input[1]').send_keys(username)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/input[2]').send_keys(password)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/input[3]').send_keys(password)
    time.sleep(3)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/button').click()
    time.sleep(3)
    if (driver.current_url) == ('https://ades-ecommerce.herokuapp.com/dashboard'):
        userPassedTests.append('Customer Register')
        print('Customer Register Test Passed')
    else:
         userFailedTests.append('Customer Register')

    #customer logout
    time.sleep(5)
    driver.find_element_by_xpath('//*[@id="root"]/div/div/button').click()
    if (True):
        userPassedTests.append('Customer Logout')
        print('Customer Logout Test Passed')
    else:
        userFailedTests.append('Customer Logout')
    time.sleep(3)


    #customer login
    driver.find_element_by_xpath('//*[@id="root"]/div/div/div/div/div/div[1]/div/div/a').click() 
    time.sleep(3)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/input[1]').send_keys(username)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/input[2]').send_keys(password)
    time.sleep(3)
    driver.find_element_by_xpath('//*[@id="root"]/div/form/button').click()
    time.sleep(3)
    if (driver.current_url) == ('https://ades-ecommerce.herokuapp.com/dashboard'):
        userPassedTests.append('Customer Login')
        print('Customer Login Test Passed')
    else:
         userFailedTests.append('Customer Login')




    #customer view product
    time.sleep(3)
    try:
        if (driver.find_element_by_xpath('//*[@id="root"]/div/div/div[2]/div/div/div/div/h5').text):
            userPassedTests.append('View Products')
            print('Customer View Products Test Passed')
    except NoSuchElementException:
        userFailedTests.append('View Products')
        pass

    print('Customer Panel Passed Tests:', userPassedTests)
    print('Customer Failed tests:', userFailedTests)



   
adminLogin()




frequency = 1000 
duration = 1000 

        




# driver.find_element_by_xpath('/html/body/div[1]/div/header/div/div/div/section[5]/div[2]/div/div[3]/div/div/div/div/nav[1]/ul/li/a/text()')
# driver.find_element_by_xpath('//*[@id="search-submit"]').click() 

# actions.move_to_element(driver.find_element_by_xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[4]/form/table/tbody/tr[1]/td[1]/div/span[7]/a")).click().perform()


#driver.close()
